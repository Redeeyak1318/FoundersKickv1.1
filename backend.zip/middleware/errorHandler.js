/**
 * Express global error handler.
 * Catches any unhandled errors thrown inside route handlers / middleware.
 */
const errorHandler = (err, _req, res, _next) => {
  console.error('🔥 Unhandled Error:', err);

  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal server error';

  res.status(statusCode).json({
    success: false,
    error: message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
};

export default errorHandler;
